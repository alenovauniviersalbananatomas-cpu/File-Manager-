// app.js

// Inicialización básica window.addEventListener('load', () => { console.log('File Manager iniciado'); });

async function solicitarPermisoAlmacenamiento() { if (navigator.storage && navigator.storage.persist) { const permiso = await navigator.storage.persist(); console.log('Almacenamiento persistente:', permiso); } }

async function abrirArchivos() { try { const [archivo] = await window.showOpenFilePicker(); const file = await archivo.getFile(); console.log('Archivo seleccionado:', file); } catch (err) { console.error('Error al abrir archivo:', err); } }

async function crearArchivo(nombre = 'nuevo.txt', contenido = '') { try { const handler = await window.showSaveFilePicker({ suggestedName: nombre }); const writable = await handler.createWritable(); await writable.write(contenido); await writable.close(); console.log('Archivo creado:', nombre); } catch (err) { console.error('Error al crear archivo:', err); } }

if ('serviceWorker' in navigator) { navigator.serviceWorker.register('./service-worker.js') .then(() => console.log('Service Worker registrado')) .catch(err => console.error('Error registrando Service Worker:', err)); }